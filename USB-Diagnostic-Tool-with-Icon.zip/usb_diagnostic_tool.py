#!/usr/bin/env python3
# USB Diagnostic Tool - v1.1 (with icon support via build script)
# See README for details.

import os
import sys
import time
import json
import shutil
import threading
import platform
from datetime import datetime
from tkinter import Tk, ttk, StringVar, messagebox, filedialog

APP_NAME = "USB Diagnostic Tool"
APP_VERSION = "1.1"

def human_bytes(num):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if num < 1024.0:
            return f"{num:.2f} {unit}"
        num /= 1024.0
    return f"{num:.2f} PB"

def _win_list_removable_drives():
    import ctypes
    drives = []
    drive_bits = ctypes.windll.kernel32.GetLogicalDrives()
    for i in range(26):
        if drive_bits & (1 << i):
            drive_letter = f"{chr(65+i)}:\\"
            drive_type = ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(drive_letter))
            if drive_type == 2:  # DRIVE_REMOVABLE
                drives.append(drive_letter)
    return drives

def _win_get_fs_info(path):
    import ctypes
    vol_name_buf = ctypes.create_unicode_buffer(261)
    fs_name_buf = ctypes.create_unicode_buffer(261)
    serial_num = ctypes.c_uint(0)
    max_comp_len = ctypes.c_uint(0)
    file_sys_flags = ctypes.c_uint(0)
    rc = ctypes.windll.kernel32.GetVolumeInformationW(
        ctypes.c_wchar_p(path),
        vol_name_buf,
        len(vol_name_buf),
        ctypes.byref(serial_num),
        ctypes.byref(max_comp_len),
        ctypes.byref(file_sys_flags),
        fs_name_buf,
        len(fs_name_buf),
    )
    if rc:
        return (fs_name_buf.value or "Unknown", vol_name_buf.value or "Unnamed")
    return ("Unknown", "Unnamed")

def list_usb_volumes():
    info_list = []
    system = platform.system()
    try:
        if system == "Windows":
            roots = _win_list_removable_drives()
            for root in roots:
                total, used, free = shutil.disk_usage(root)
                fs, label = _win_get_fs_info(root)
                info_list.append({
                    "mount": root,
                    "filesystem": fs,
                    "label": label,
                    "total_bytes": int(total),
                    "free_bytes": int(free),
                    "used_bytes": int(used),
                })
            return info_list
    except Exception as e:
        print("Windows detection error:", e, file=sys.stderr)

    parts = []
    try:
        import psutil
        for p in psutil.disk_partitions(all=False):
            parts.append((p.device, p.mountpoint, p.fstype, getattr(p, "opts", "")))
    except Exception:
        guess_mounts = []
        for base in ["/Volumes", "/media", "/run/media"]:
            if os.path.isdir(base):
                for root, dirs, files in os.walk(base):
                    for d in dirs:
                        guess_mounts.append(os.path.join(root, d))
        parts = [(m, m, "unknown", "") for m in guess_mounts]

    for dev, mnt, fstype, opts in parts:
        try:
            total, used, free = shutil.disk_usage(mnt)
            info_list.append({
                "mount": mnt,
                "filesystem": fstype or "Unknown",
                "label": os.path.basename(mnt) or "Unnamed",
                "total_bytes": int(total),
                "free_bytes": int(free),
                "used_bytes": int(used),
            })
        except Exception:
            pass

    return info_list

def run_benchmark(target_mount, size_mb=64):
    import os, time
    size_bytes = size_mb * 1024 * 1024
    temp_path = os.path.join(target_mount, "USB_Diagnostic_Tool_Benchmark.tmp")
    total, used, free = shutil.disk_usage(target_mount)
    if free < size_bytes * 2:
        raise RuntimeError("Not enough free space for benchmark. Reduce test size.")
    chunk = b"\x00" * (4 * 1024 * 1024)
    bytes_written = 0
    t0 = time.perf_counter()
    with open(temp_path, "wb", buffering=0) as f:
        while bytes_written < size_bytes:
            write_len = min(len(chunk), size_bytes - bytes_written)
            f.write(chunk[:write_len])
            f.flush()
            os.fsync(f.fileno())
            bytes_written += write_len
    t1 = time.perf_counter()
    write_time = t1 - t0
    write_speed = bytes_written / write_time if write_time > 0 else 0
    read_bytes = 0
    t2 = time.perf_counter()
    with open(temp_path, "rb", buffering=0) as f:
        while True:
            data = f.read(4 * 1024 * 1024)
            if not data: break
            read_bytes += len(data)
    t3 = time.perf_counter()
    read_time = t3 - t2
    read_speed = read_bytes / read_time if read_time > 0 else 0
    try:
        os.remove(temp_path)
    except Exception:
        pass
    return {
        "write_MBps": write_speed / (1024*1024),
        "read_MBps": read_speed / (1024*1024),
        "test_size_MB": size_mb,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }

def build_report(volumes, selected_mount=None, bench=None):
    return {
        "app": APP_NAME,
        "version": APP_VERSION,
        "system": {
            "platform": platform.platform(),
            "python": sys.version.split()[0]
        },
        "scan_time": datetime.utcnow().isoformat() + "Z",
        "volumes": volumes,
        "selected": selected_mount,
        "benchmark": bench,
    }

class App:
    def __init__(self, root):
        self.root = root
        root.title(f"{APP_NAME} v{APP_VERSION}")
        root.geometry("760x520")
        self.status = StringVar(value="Ready.")
        self.bench_size_mb = StringVar(value="64")

        frm = ttk.Frame(root, padding=10)
        frm.pack(fill="both", expand=True)

        top = ttk.Frame(frm)
        top.pack(fill="x", pady=(0, 8))

        ttk.Label(top, text="Benchmark size (MB):").pack(side="left")
        ttk.Entry(top, textvariable=self.bench_size_mb, width=6).pack(side="left", padx=(6,12))
        ttk.Button(top, text="Refresh", command=self.refresh).pack(side="left")
        ttk.Button(top, text="Run Benchmark", command=self.run_bench_clicked).pack(side="left", padx=(6,0))
        ttk.Button(top, text="Export Report", command=self.export_report).pack(side="left", padx=(6,0))

        columns = ("mount", "label", "filesystem", "total", "used", "free")
        self.tree = ttk.Treeview(frm, columns=columns, show="headings", height=15)
        for col, width in zip(columns, (120, 160, 120, 110, 110, 110)):
            self.tree.heading(col, text=col.capitalize())
            self.tree.column(col, width=width, anchor="center")
        self.tree.pack(fill="both", expand=True)

        ttk.Separator(frm).pack(fill="x", pady=6)
        ttk.Label(frm, textvariable=self.status).pack(anchor="w")

        self.volumes = []
        self._last_benchmark = None
        self.refresh()

    def refresh(self):
        self.status.set("Scanning for removable/USB drives...")
        self.root.update_idletasks()
        self.volumes = list_usb_volumes()
        for row in self.tree.get_children():
            self.tree.delete(row)
        for v in self.volumes:
            self.tree.insert(
                "", "end",
                values=(
                    v["mount"],
                    v.get("label",""),
                    v.get("filesystem",""),
                    human_bytes(v["total_bytes"]),
                    human_bytes(v["used_bytes"]),
                    human_bytes(v["free_bytes"]),
                )
            )
        self.status.set(f"Found {len(self.volumes)} removable volume(s)." if self.volumes else "No removable/USB volumes found.")

    def _get_selected_mount(self):
        sel = self.tree.focus()
        if not sel: return None
        vals = self.tree.item(sel, "values")
        return vals[0] if vals else None

    def run_bench_clicked(self):
        mount = self._get_selected_mount()
        if not mount:
            messagebox.showinfo(APP_NAME, "Please select a drive in the list first.")
            return
        try:
            size_mb = int(self.bench_size_mb.get().strip())
            if size_mb < 4 or size_mb > 4096: raise ValueError
        except Exception:
            messagebox.showerror(APP_NAME, "Benchmark size must be an integer between 4 and 4096 MB.")
            return

        def worker():
            try:
                self.status.set(f"Running benchmark on {mount} ({size_mb} MB)...")
                self.root.update_idletasks()
                res = run_benchmark(mount, size_mb=size_mb)
                self._last_benchmark = res
                msg = f"Write: {res['write_MBps']:.1f} MB/s\nRead: {res['read_MBps']:.1f} MB/s"
                self.status.set(f"Benchmark complete. {msg.replace(chr(10),'  ')}")
                messagebox.showinfo(APP_NAME, msg)
            except Exception as e:
                self.status.set("Benchmark failed.")
                messagebox.showerror(APP_NAME, f"Benchmark failed:\n{e}")
        threading.Thread(target=worker, daemon=True).start()

    def export_report(self):
        mount = self._get_selected_mount()
        rep = build_report(self.volumes, selected_mount=mount, bench=self._last_benchmark)
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        default_name = f"USB_Diagnostic_Report_{ts}.json"
        save_path = filedialog.asksaveasfilename(defaultextension=".json", initialfile=default_name,
                                                 filetypes=[("JSON files","*.json"), ("All files","*.*")])
        if not save_path: return
        try:
            with open(save_path, "w", encoding="utf-8") as f:
                json.dump(rep, f, indent=2)
            messagebox.showinfo(APP_NAME, f"Report saved:\n{save_path}")
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Failed to save report:\n{e}")

def main():
    if len(sys.argv) > 1 and sys.argv[1] in ("--scan", "-s"):
        vols = list_usb_volumes()
        print(json.dumps(vols, indent=2))
        return
    root = Tk()
    try:
        style = ttk.Style()
        if platform.system() == "Windows":
            style.theme_use("vista")
    except Exception:
        pass
    App(root)
    root.mainloop()

if __name__ == "__main__":
    main()
